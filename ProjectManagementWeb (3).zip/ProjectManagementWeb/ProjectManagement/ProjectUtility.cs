﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement
{
    public class ProjectUtility
    {
        public string GenerateProjectID(string strProjectName)
        {
            //throw new NotImplementedException();
            string[] strArr = strProjectName.Split(' ');
            string resStr = "";
            if(strArr.Length == 1)
            {
                char[] charArr = strArr[0].ToCharArray();
                resStr = charArr[0].ToString() + charArr[1].ToString() + charArr[2].ToString();
            }
            else if(strArr.Length == 2)
            {
                char[] charArr1 = strArr[0].ToCharArray();
                char[] charArr2 = strArr[1].ToCharArray();
                resStr = charArr1[0].ToString() + charArr2[0].ToString() + charArr2[1].ToString();
            }
            else if(strArr.Length == 3)
            {
                char[] charArr1 = strArr[0].ToCharArray();
                char[] charArr2 = strArr[1].ToCharArray();
                char[] charArr3 = strArr[2].ToCharArray();
                resStr = charArr1[0].ToString() + charArr2[0].ToString() + charArr3[0].ToString();
            }

            return resStr.ToUpper();
        }
    }
}
