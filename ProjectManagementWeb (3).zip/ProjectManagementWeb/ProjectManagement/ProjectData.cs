﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManagement
{
    public class ProjectData
    {
        const string ConnectionString = "Server=.;Initial Catalog=ProjectManagement;User ID=sa;Password=wipro@123";
        public string AddProject(Project obj)
        {
            //throw new NotImplementedException();
            if(obj == null)
            {
                return null;
            }
            else
            {
                ProjectUtility pUti = new ProjectUtility();
                string ProjId = pUti.GenerateProjectID(obj.ProjectName);
                Random ran = new Random();
                int r = ran.Next(100, 1000);
                ProjId += r.ToString();
                obj.ProjectID = ProjId;
                obj.Duration= (int)(obj.EndDate.Subtract(obj.StartDate).TotalDays);

                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("INSERT INTO PROJECTS VALUES(@pid,@pnm,@sdt,@edt,@dur)", con);
                cmd.Parameters.AddWithValue("@pid", obj.ProjectID);
                cmd.Parameters.AddWithValue("@pnm", obj.ProjectName);
                cmd.Parameters.AddWithValue("@sdt", obj.StartDate);
                cmd.Parameters.AddWithValue("@edt", obj.EndDate);
                cmd.Parameters.AddWithValue("@dur", obj.Duration);

                con.Open();
                int rows=cmd.ExecuteNonQuery();
                con.Close();
                if (rows == 1)
                {
                    return obj.ProjectID;
                }
                else
                    return null;
            }
        }

        public Project GetProjctByID(string strProjectID)
        {
            //throw new NotImplementedException();
            if(String.IsNullOrEmpty(strProjectID))
            {
                return null;
            }
            else
            {
                Project obj = new Project();
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("SELECT * FROM PROJECTS WHERE PROJECTID=@pid", con);
                cmd.Parameters.AddWithValue("@pid", strProjectID);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if(dr.HasRows)
                {
                    dr.Read();
                    obj.ProjectID = dr["ProjectID"].ToString();
                    obj.ProjectName = dr["ProjectName"].ToString();
                    obj.StartDate =DateTime.Parse(dr["StartDate"].ToString());
                    obj.EndDate = DateTime.Parse(dr["EndDate"].ToString());
                    obj.Duration = int.Parse(dr["Duration"].ToString());
                }
                con.Close();
                return obj;
            }
        }

        public int UpdateProject(Project obj)
        {
            //throw new NotImplementedException();
            if(obj == null)
            {
                return -1;
            }
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("UPDATE PROJECTS SET PROJECTNAME=@pnm,STARTDATE=@sdt,ENDDATE=@edt,DURATION=@dur WHERE PROJECTID=@pid", con);
                cmd.Parameters.AddWithValue("@pid", obj.ProjectID);
                cmd.Parameters.AddWithValue("@pnm", obj.ProjectName);
                cmd.Parameters.AddWithValue("@sdt", obj.StartDate);
                cmd.Parameters.AddWithValue("@edt", obj.EndDate);
                cmd.Parameters.AddWithValue("@dur", obj.Duration);

                con.Open();
                int rows=cmd.ExecuteNonQuery();
                con.Close();
                if(rows > 0)
                {
                    return rows;
                }
                else
                {
                    return 0;
                }

            }
        }

        public int DeleteProject(string strProjectID)
        {
            //throw new NotImplementedException();
            if (String.IsNullOrEmpty(strProjectID))
            {
                return -1;
            }
            else
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                SqlCommand cmd = new SqlCommand("DELETE FROM PROJECTS WHERE PROJECTID=@pid", con);
                cmd.Parameters.AddWithValue("@pid", strProjectID);
                con.Open();
                int rows = cmd.ExecuteNonQuery();
                con.Close();
                if(rows > 0)
                {
                    return rows;
                }
                else
                {
                    return 0;
                }
            }
        }
    }
}
